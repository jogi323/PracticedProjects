var express = require('express');
var app = express();
app.set('view engine','ejs');
app.get('/', function (req, res) {
   res.sendFile(__dirname + '/index.html');
});
app.get('/contact',function(req,res){
  res.send('This is a contact Page.so, You can get our Office addresses here.')
});
app.get('/profile/:name',function(req,res){
  var data = {empId:2452,designation:'Associate Engineer',hobbies:['playing','reading','listening music']};
  res.render('profile' , { person: req.params.name,data:data} );
});
app.listen(2000);
console.log('programe is running in the given port.');
